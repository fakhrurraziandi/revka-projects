<?php 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <!-- Custom fonts for this template-->
        
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,8a00i,900,900i" rel="stylesheet">
        <!-- Custom styles for this template-->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body id="page-top">

        <div class="loader">
            <div class="loader-inner">
                <div class="spinner-border text-primary" style="border-width: 5px;" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        </div>
        <!-- Page Wrapper -->
        <div id="wrapper">
            <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
                <!-- Sidebar - Brand -->
                <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                    <div class="sidebar-brand-icon">
                        <i class="fas fa-th-large"></i>
                    </div>
                    <div class="sidebar-brand-text mx-3"><small class="h5"><?php echo e(config('app.name', 'Laravel')); ?></small></div>
                </a>
                <!-- Divider -->
                <hr class="sidebar-divider my-0">
                <!-- Nav Item - Dashboard -->
                <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(url('home')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
                </li>
                <!-- Divider -->
                <hr class="sidebar-divider">
                <!-- Heading -->
                <div class="sidebar-heading">
                    Interface
                </div>


                

                

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.settings')); ?>">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Settings</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.header_carousel.index')); ?>">
                    <i class="fas fa-fw fa-images"></i>
                    <span>Header Carousel</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.service_carousel.index')); ?>">
                    <i class="fas fa-fw fa-handshake"></i>
                    <span>Services</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.value_content.index')); ?>">
                    <i class="fas fa-fw fa-paragraph"></i>
                    <span>Value Content</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.client_testimonial.index')); ?>">
                    <i class="fas fa-fw fa-quote-right"></i>
                    <span>Client Testimonials</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.portofolio.index')); ?>">
                    <i class="fas fa-fw fa-images"></i>
                    <span>Portofolios</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('app.user.index')); ?>">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Users</span></a>
                </li>


                
                <!-- Divider -->
                <hr class="sidebar-divider d-none d-md-block">
                <!-- Sidebar Toggler (Sidebar) -->
                <div class="text-center d-none d-md-inline">
                    <button class="rounded-circle border-0" id="sidebarToggle"></button>
                </div>
            </ul>
            <!-- End of Sidebar -->
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <!-- Main Content -->
                <div id="content">
                    <!-- Topbar -->
                    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                        <!-- Sidebar Toggle (Topbar) -->
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                        </button>
                        <!-- Topbar Search -->
                        
                        <!-- Topbar Navbar -->
                        <ul class="navbar-nav ml-auto">
                            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                            
                            <!-- Nav Item - User Information -->
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600"><?php echo e(Auth::user()->name); ?></span>
                                <img class="img-profile rounded-circle" src="<?php echo e(asset('design/dist/images/avatar.jpg')); ?>">
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                   
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Logout
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </nav>
                    <!-- End of Topbar -->
                    <!-- Begin Page Content -->

                    <?php echo $__env->yieldContent('content'); ?>
                    
                </div>
                <!-- End of Main Content -->
                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Copyright &copy; Your Website 2019</span>
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->
            </div>
            <!-- End of Content Wrapper -->
        </div>
        <!-- End of Page Wrapper -->
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
        </a>
        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

        <script>
            var base_url = '<?php echo e(URL::to('/')); ?>';
    
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
    
        

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\revka-projects\resources\views/layouts/app.blade.php ENDPATH**/ ?>