<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            

            <div class="card border-0 shadow-sm">
                <div class="card-header"><?php echo e(isset($portofolio) ? 'Edit Portofolio' : 'Add New Portofolio'); ?></div>
                <div class="card-body">
                    
                    
                    <?php if(isset($portofolio)): ?>
                        <form action="<?php echo e(route('app.portofolio.update', $portofolio->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php else: ?>
                        <form action="<?php echo e(route('app.portofolio.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php endif; ?>

                        <?php echo csrf_field(); ?>

                        <?php if(isset($portofolio)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="form-group row">
                            <label for="title" class="col-sm-2 col-form-label text-sm-right">Title</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" id="title" name="title" placeholder="Title" value="<?php echo e(old('title', (isset($portofolio) ? $portofolio->title : null))); ?>">
                                <?php if($errors->has('title')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('title')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-sm-2 col-form-label text-sm-right">Description</label>
                            <div class="col-sm-6">
                                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" placeholder="Description" rows="7"><?php echo e(old('description', (isset($portofolio) ? $portofolio->description : null))); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('description')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="image_file" class="col-sm-2 col-form-label text-sm-right">Image File</label>
                            <div class="col-sm-6">
                                <input type="file" class="form-control <?php echo e($errors->has('image_file') ? 'is-invalid' : ''); ?>" id="image_file" name="image_file" placeholder="Image File" value="<?php echo e(old('image_file', (isset($portofolio) ? $portofolio->image_file : null))); ?>">
                                
                                <?php if(isset($portofolio)): ?>
                                    <p class="my-2">ignore if you don't want to replace the image</p>
                                <?php endif; ?>

                                <?php if($errors->has('image_file')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('image_file')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                       

                        <div class="row mt-3">
                            <div class="col-sm-10 offset-sm-2">
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a href="<?php echo e(route('app.portofolio.index')); ?>" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revka-projects\resources\views/app/portofolio/form.blade.php ENDPATH**/ ?>