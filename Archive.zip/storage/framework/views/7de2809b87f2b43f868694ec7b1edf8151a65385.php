<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo e(route('app.settings.store')); ?>" class="form-horizontal" role="form">
                <?php echo csrf_field(); ?>


                <?php if(count(config('setting_fields', [])) ): ?>

                    <?php $__currentLoopData = config('setting_fields'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-info mb-3">
                            <div class="card-header">
                                <i class="<?php echo e(array_get($fields, 'icon', 'glyphicon glyphicon-flash')); ?>"></i>
                                <?php echo e($fields['title']); ?>

                            </div>
                            

                            <div class="card-body">
                                <h5 class="text-muted"><?php echo e($fields['desc']); ?></h5>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-12">
                                        
                                        <?php $__currentLoopData = $fields['elements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php if ($__env->exists('app.setting.fields.' . $field['type'] )) echo $__env->make('app.setting.fields.' . $field['type'] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!-- end card for <?php echo e($fields['title']); ?> -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

                <div class="row m-b-md my-3">
                    <div class="col-md-12">
                        <button class="btn-primary btn">
                            Save Settings
                        </button>
                    </div>
                </div>
            </form>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revka-projects\resources\views/app/setting/index.blade.php ENDPATH**/ ?>