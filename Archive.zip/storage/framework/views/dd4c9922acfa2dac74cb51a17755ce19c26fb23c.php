<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            

            <div class="card border-0 shadow-sm">
                <div class="card-header"><?php echo e(isset($client_testimonial) ? 'Edit Client Testimonial' : 'Add New Client Testimonial'); ?></div>
                <div class="card-body">
                    
                    
                    <?php if(isset($client_testimonial)): ?>
                        <form action="<?php echo e(route('app.client_testimonial.update', $client_testimonial->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php else: ?>
                        <form action="<?php echo e(route('app.client_testimonial.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php endif; ?>

                        <?php echo csrf_field(); ?>

                        <?php if(isset($client_testimonial)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label text-sm-right">Name</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" placeholder="Name" value="<?php echo e(old('name', (isset($client_testimonial) ? $client_testimonial->name : null))); ?>">
                                <?php if($errors->has('name')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('name')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="testimonial" class="col-sm-2 col-form-label text-sm-right">Testimonial</label>
                            <div class="col-sm-6">
                                <textarea class="form-control <?php echo e($errors->has('testimonial') ? 'is-invalid' : ''); ?>" id="testimonial" name="testimonial" placeholder="Testimonial" rows="7"><?php echo e(old('testimonial', (isset($client_testimonial) ? $client_testimonial->testimonial : null))); ?></textarea>
                                <?php if($errors->has('testimonial')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('testimonial')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="image_file" class="col-sm-2 col-form-label text-sm-right">Image File</label>
                            <div class="col-sm-6">
                                <input type="file" class="form-control <?php echo e($errors->has('image_file') ? 'is-invalid' : ''); ?>" id="image_file" name="image_file" placeholder="Image File" value="<?php echo e(old('image_file', (isset($client_testimonial) ? $client_testimonial->image_file : null))); ?>">
                                
                                <?php if(isset($client_testimonial)): ?>
                                    <p class="my-2">ignore if you don't want to replace the image</p>
                                <?php endif; ?>

                                <?php if($errors->has('image_file')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('image_file')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                       

                        <div class="row mt-3">
                            <div class="col-sm-10 offset-sm-2">
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a href="<?php echo e(route('app.client_testimonial.index')); ?>" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revka-projects\resources\views/app/client_testimonial/form.blade.php ENDPATH**/ ?>