
<div class="form-group <?php echo e($errors->has($field['name']) ? ' has-error' : ''); ?>">
    <label for="<?php echo e($field['name']); ?>"><?php echo e($field['label']); ?></label>
    <textarea name="<?php echo e($field['name']); ?>" 
                id="<?php echo e($field['name']); ?>" 
                cols="30" 
                rows="7" 
                class="form-control <?php echo e(array_get( $field, 'class')); ?>"><?php echo e(old($field['name'], \setting($field['name']))); ?></textarea>

    <?php if($errors->has($field['name'])): ?> <small class="help-block"><?php echo e($errors->first($field['name'])); ?></small> <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\revka-projects\resources\views/app/setting/fields/textarea.blade.php ENDPATH**/ ?>